from .cob_widget import CoBWidget


